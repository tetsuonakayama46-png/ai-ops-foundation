"""社内チャット（LINE公式アカウント or Slack）。
- post_brief: 経営者本人／社内グループへのブリーフィング配信（自動許可）
- send_external: 顧客など外部宛の送信（承認必須・カテゴリA）
"""
from __future__ import annotations

import os

import requests

from ..approval.gate import gate, requires_approval

LINE_API = "https://api.line.me/v2/bot/message"


def _line_headers():
    return {"Authorization": f"Bearer {os.getenv('LINE_CHANNEL_ACCESS_TOKEN', '')}",
            "Content-Type": "application/json"}


def _approval_buttons(pending: list) -> list[dict]:
    """承認待ちをLINEのボタンテンプレートで送る（1件=1メッセージ）。"""
    msgs = []
    for rec in pending[:5]:  # LINEは1回5メッセージまで
        msgs.append({
            "type": "template",
            "altText": f"承認依頼 [{rec.id}] {rec.summary}",
            "template": {
                "type": "confirm",
                "text": f"[{rec.id}] {rec.category}\n{rec.summary}"[:240],
                "actions": [
                    {"type": "postback", "label": "承認", "data": f"act=approve&id={rec.id}"},
                    {"type": "postback", "label": "却下", "data": f"act=reject&id={rec.id}"},
                ],
            },
        })
    return msgs


def post_brief(text: str, pending: list | None = None) -> None:
    gate().check("chat.post_brief", {"len": len(text)}, "ブリーフィング配信")
    provider = os.getenv("CHAT_PROVIDER", "line")
    if provider == "line":
        msgs = [{"type": "text", "text": text[:5000]}]
        if pending:
            msgs += _approval_buttons(pending)
        r = requests.post(f"{LINE_API}/push", headers=_line_headers(),
                          json={"to": os.getenv("LINE_TARGET_ID"), "messages": msgs[:5]}, timeout=15)
        r.raise_for_status()
    elif provider == "slack":
        body = text + ("\n\n承認待ち: " + ", ".join(f"[{p.id}] {p.summary}" for p in pending) if pending else "")
        r = requests.post("https://slack.com/api/chat.postMessage",
                          headers={"Authorization": f"Bearer {os.getenv('SLACK_BOT_TOKEN', '')}"},
                          json={"channel": os.getenv("SLACK_CHANNEL_ID"), "text": body}, timeout=15)
        r.raise_for_status()
    else:
        raise ValueError(f"unknown CHAT_PROVIDER {provider}")


def reply_line(reply_token: str | None, text: str) -> None:
    if not reply_token:
        return
    requests.post(f"{LINE_API}/reply", headers=_line_headers(),
                  json={"replyToken": reply_token, "messages": [{"type": "text", "text": text}]}, timeout=15)


@requires_approval("chat.send_external", summarize=lambda to, text, **_: f"外部チャット送信 to={to}: {text[:40]}")
def send_external(to: str, text: str) -> None:
    r = requests.post(f"{LINE_API}/push", headers=_line_headers(),
                      json={"to": to, "messages": [{"type": "text", "text": text}]}, timeout=15)
    r.raise_for_status()
