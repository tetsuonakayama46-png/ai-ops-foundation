"""Google OAuth（Gmail / Calendar / Tasks 共通）。
スコープは最小権限。送信・削除は gate を通した関数からのみ呼ぶ。"""
from __future__ import annotations

import os
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = [
    "https://www.googleapis.com/auth/gmail.modify",       # 読み取り＋下書き＋ラベル（削除は別途gate）
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/tasks.readonly",
]


def credentials() -> Credentials:
    secret = os.getenv("GOOGLE_CLIENT_SECRET_FILE", "config/google_client_secret.json")
    token_file = Path(os.getenv("GOOGLE_TOKEN_FILE", "data/google_token.json"))
    creds = None
    if token_file.exists():
        creds = Credentials.from_authorized_user_file(str(token_file), SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            # 初回のみブラウザ認可（scripts/oauth_init.py から実行）
            flow = InstalledAppFlow.from_client_secrets_file(secret, SCOPES)
            creds = flow.run_local_server(port=0)
        token_file.parent.mkdir(parents=True, exist_ok=True)
        token_file.write_text(creds.to_json(), encoding="utf-8")
    return creds


def service(name: str, version: str):
    return build(name, version, credentials=credentials(), cache_discovery=False)
