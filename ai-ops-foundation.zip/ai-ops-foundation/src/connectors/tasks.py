"""Google Tasks：期限切れ・本日期限の未完了タスク。
社内ToDoが別ツール（Notion等）なら、この関数と同じ戻り値形式で差し替える。"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .google_auth import service

JST = timezone(timedelta(hours=9))


def due_tasks() -> dict[str, list[dict]]:
    svc = service("tasks", "v1")
    today = datetime.now(JST).date()
    overdue, due_today = [], []
    for tl in svc.tasklists().list(maxResults=20).execute().get("items", []):
        res = svc.tasks().list(tasklist=tl["id"], showCompleted=False, maxResults=100).execute()
        for t in res.get("items", []):
            due = t.get("due")
            if not due:
                continue
            d = datetime.fromisoformat(due.replace("Z", "+00:00")).astimezone(JST).date()
            item = {"title": t.get("title", ""), "list": tl.get("title", ""), "due": d.isoformat()}
            if d < today:
                overdue.append(item)
            elif d == today:
                due_today.append(item)
    return {"overdue": overdue, "today": due_today}
