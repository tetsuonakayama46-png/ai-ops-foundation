"""Gmail コネクター。読み取り＋下書きは自動、送信・削除は承認ゲート。"""
from __future__ import annotations

import base64
from email.mime.text import MIMEText

from ..approval.gate import requires_approval
from .google_auth import service


def _svc():
    return service("gmail", "v1")


def list_unread(query: str, max_results: int = 30) -> list[dict]:
    """未読メールのメタ情報（From/Subject/Date/Snippet）。本文は取らない＝トークン節約。"""
    svc = _svc()
    res = svc.users().messages().list(userId="me", q=query, maxResults=max_results).execute()
    out = []
    for m in res.get("messages", []):
        msg = svc.users().messages().get(
            userId="me", id=m["id"], format="metadata",
            metadataHeaders=["From", "Subject", "Date"]).execute()
        h = {x["name"]: x["value"] for x in msg["payload"].get("headers", [])}
        out.append({"id": m["id"], "threadId": msg.get("threadId"),
                    "from": h.get("From", ""), "subject": h.get("Subject", "(件名なし)"),
                    "date": h.get("Date", ""), "snippet": msg.get("snippet", "")})
    return out


def create_draft(to: str, subject: str, body: str, thread_id: str | None = None) -> str:
    """下書き作成（自動許可）。送信は行わない。"""
    from ..approval.gate import gate
    gate().check("gmail.create_draft", {"to": to, "subject": subject}, f"draft to={to} subj={subject}")
    mime = MIMEText(body, "plain", "utf-8")
    mime["to"], mime["subject"] = to, subject
    raw = base64.urlsafe_b64encode(mime.as_bytes()).decode()
    msg = {"message": {"raw": raw}}
    if thread_id:
        msg["message"]["threadId"] = thread_id
    d = _svc().users().drafts().create(userId="me", body=msg).execute()
    return d["id"]


# ---- 以下は承認必須（A: 送信 / D: 削除） ----

@requires_approval("gmail.send", summarize=lambda draft_id, to, subject, **_: f"メール送信 to={to} subj={subject}")
def send_draft(draft_id: str, to: str, subject: str) -> dict:
    return _svc().users().drafts().send(userId="me", body={"id": draft_id}).execute()


@requires_approval("gmail.trash", summarize=lambda message_id, subject="", **_: f"メール削除(ゴミ箱) {subject or message_id}")
def trash_message(message_id: str, subject: str = "") -> dict:
    return _svc().users().messages().trash(userId="me", id=message_id).execute()
