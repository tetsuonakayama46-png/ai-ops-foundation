"""Google カレンダー（読み取り専用スコープ）。"""
from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone

from .google_auth import service

JST = timezone(timedelta(hours=9))


def today_events(lookahead_hours: int = 24) -> list[dict]:
    svc = service("calendar", "v3")
    start = datetime.now(JST).replace(hour=0, minute=0, second=0, microsecond=0)
    end = start + timedelta(hours=lookahead_hours)
    out = []
    for cal in [c.strip() for c in os.getenv("GOOGLE_CALENDAR_IDS", "primary").split(",") if c.strip()]:
        res = svc.events().list(calendarId=cal, timeMin=start.isoformat(), timeMax=end.isoformat(),
                                singleEvents=True, orderBy="startTime", maxResults=50).execute()
        for e in res.get("items", []):
            s = e.get("start", {})
            when = s.get("dateTime") or s.get("date")
            out.append({"when": when, "title": e.get("summary", "(無題)"),
                        "location": e.get("location", ""), "allday": "date" in s and "dateTime" not in s})
    out.sort(key=lambda x: x["when"])
    return out
