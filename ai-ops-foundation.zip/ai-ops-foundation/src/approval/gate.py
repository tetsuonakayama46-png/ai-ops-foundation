"""
承認ゲート（Safeguard）
======================
要件3の実装中核。すべての「副作用のある操作」はこのモジュールを通す。

設計原則
- fail-closed: ポリシーに無いアクションは拒否。
- 承認は「人間のID」「アクション」「対象のハッシュ」「期限」で紐づく。
  → 別の宛先・別の本文に流用できない（内容が1文字でも変われば再承認）。
- 承認トークンは1回使い切り（consumed）。
- 承認なしの呼び出しは例外ではなく「ApprovalRequired」として待機キューへ登録して戻る。
  バッチは止まらず、人間が後から Approve すれば次回実行時に完了する。
"""
from __future__ import annotations

import functools
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import yaml

from .store import ApprovalStore, ApprovalRecord

ROOT = Path(__file__).resolve().parents[2]
POLICY_FILE = ROOT / "config" / "approval_policy.yaml"


class ApprovalRequired(Exception):
    """承認待ちとして登録された。処理はスキップされた。"""

    def __init__(self, record: ApprovalRecord):
        super().__init__(f"approval required: {record.action} [{record.id}]")
        self.record = record


class ForbiddenAction(Exception):
    """承認があっても実行禁止。"""


@dataclass(frozen=True)
class Policy:
    auto_allowed: frozenset[str]
    requires: dict[str, tuple[str, int]]  # action -> (category, ttl_minutes)
    forbidden: frozenset[str]

    @classmethod
    def load(cls, path: Path = POLICY_FILE) -> "Policy":
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        requires: dict[str, tuple[str, int]] = {}
        for cat, spec in (data.get("require_approval") or {}).items():
            for a in spec.get("actions", []):
                requires[a] = (cat, int(spec.get("approval_ttl_minutes", 60)))
        return cls(
            auto_allowed=frozenset(data.get("auto_allowed") or []),
            requires=requires,
            forbidden=frozenset(data.get("forbidden") or []),
        )

    def classify(self, action: str) -> str:
        if action in self.forbidden:
            return "forbidden"
        if action in self.requires:
            return "approval"
        if action in self.auto_allowed:
            return "auto"
        return "forbidden"  # fail-closed


def payload_hash(payload: Any) -> str:
    s = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(s.encode("utf-8")).hexdigest()[:24]


class Gate:
    def __init__(self, policy: Policy | None = None, store: ApprovalStore | None = None):
        self.policy = policy or Policy.load()
        self.store = store or ApprovalStore(os.getenv("APPROVAL_DB", str(ROOT / "data" / "approvals.sqlite3")))

    def check(self, action: str, payload: Any, summary: str) -> None:
        """実行前に必ず呼ぶ。通過すれば戻る。通過不可なら例外。"""
        kind = self.policy.classify(action)
        if kind == "forbidden":
            self.store.audit(action, "FORBIDDEN", summary)
            raise ForbiddenAction(f"forbidden by policy: {action}")
        if kind == "auto":
            self.store.audit(action, "AUTO", summary)
            return
        h = payload_hash(payload)
        rec = self.store.find_approved(action, h)
        if rec is None:
            cat, ttl = self.policy.requires[action]
            rec = self.store.request(action, cat, h, summary, ttl_minutes=ttl, payload=payload)
            self.store.audit(action, "PENDING", f"{summary} [{rec.id}]")
            raise ApprovalRequired(rec)
        self.store.consume(rec.id)
        self.store.audit(action, "EXECUTED", f"{summary} approved_by={rec.approved_by} [{rec.id}]")


_default_gate: Gate | None = None


def gate() -> Gate:
    global _default_gate
    if _default_gate is None:
        _default_gate = Gate()
    return _default_gate


def requires_approval(action: str, summarize: Callable[..., str] | None = None):
    """
    副作用関数に付けるデコレータ。
        @requires_approval("gmail.send", summarize=lambda to, subject, **_: f"to={to} subj={subject}")
        def send_mail(to, subject, body): ...
    呼び出し時に承認が無ければ ApprovalRequired を送出し、関数本体は実行されない。
    """

    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            payload = {"args": args, "kwargs": kwargs}
            summary = summarize(*args, **kwargs) if summarize else f"{action}({payload_hash(payload)})"
            gate().check(action, payload, summary)
            return fn(*args, **kwargs)

        wrapper.__action__ = action  # type: ignore[attr-defined]
        return wrapper

    return deco
