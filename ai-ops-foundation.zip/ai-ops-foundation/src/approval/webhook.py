"""
承認Webhook（LINE Messaging API 版）
- ブリーフィングに付く「承認」「却下」ボタン（postback）を受け取り、ApprovalStore を更新する。
- 常駐は不要。cron実行時のみ起動する運用でもよいが、ボタンを即時反映したいなら systemd で常駐させる。
  常駐しても LLM は一切呼ばないので利用枠は消費しない。
起動: uvicorn src.approval.webhook:app --port ${APPROVAL_WEBHOOK_PORT}
LINE Developers の Webhook URL に https://<host>/line/webhook を登録。
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
from urllib.parse import parse_qs

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request

from .store import ApprovalStore

load_dotenv()
app = FastAPI(title="ai-ops approval webhook")


def _store() -> ApprovalStore:
    return ApprovalStore(os.getenv("APPROVAL_DB", "data/approvals.sqlite3"))


def _verify(body: bytes, signature: str | None) -> None:
    secret = os.getenv("LINE_CHANNEL_SECRET", "").encode()
    if not secret or not signature:
        raise HTTPException(401, "no signature")
    mac = hmac.new(secret, body, hashlib.sha256).digest()
    if not hmac.compare_digest(base64.b64encode(mac).decode(), signature):
        raise HTTPException(401, "bad signature")


@app.post("/line/webhook")
async def line_webhook(request: Request, x_line_signature: str | None = Header(default=None)):
    body = await request.body()
    _verify(body, x_line_signature)
    data = await request.json()
    store = _store()
    from ..connectors.chat import reply_line  # 遅延import

    for ev in data.get("events", []):
        if ev.get("type") != "postback":
            continue
        q = parse_qs(ev["postback"]["data"])
        act, rid = q.get("act", [""])[0], q.get("id", [""])[0].upper()
        user = ev.get("source", {}).get("userId", "")
        if act == "approve":
            ok = store.approve(rid, user)
            msg = f"✅ 承認 {rid}（次回実行時に処理）" if ok else f"⚠️ 承認できません {rid}（権限なし/期限切れ）"
        elif act == "reject":
            ok = store.reject(rid, user)
            msg = f"🚫 却下 {rid}" if ok else f"⚠️ 対象なし {rid}"
        else:
            continue
        reply_line(ev.get("replyToken"), msg)
    return {"ok": True}
