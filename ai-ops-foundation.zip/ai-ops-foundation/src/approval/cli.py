"""
承認CLI（承認ボタンの代替。LINE/Slackの webhook が無い環境でも承認できる）
  python -m src.approval.cli list
  python -m src.approval.cli approve <ID> --by <承認者ID>
  python -m src.approval.cli reject  <ID> --by <承認者ID>
  python -m src.approval.cli audit [--n 50]
"""
from __future__ import annotations

import argparse
import os

from dotenv import load_dotenv

from .store import ApprovalStore


def main():
    load_dotenv()
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    a = sub.add_parser("approve"); a.add_argument("id"); a.add_argument("--by", required=True)
    r = sub.add_parser("reject"); r.add_argument("id"); r.add_argument("--by", required=True)
    au = sub.add_parser("audit"); au.add_argument("--n", type=int, default=50)
    args = p.parse_args()

    store = ApprovalStore(os.getenv("APPROVAL_DB", "data/approvals.sqlite3"))
    if args.cmd == "list":
        rows = store.pending()
        if not rows:
            print("承認待ちはありません。")
        for x in rows:
            print(f"[{x.id}] {x.category} {x.action}\n    {x.summary}\n    期限: {x.expires_at}")
    elif args.cmd == "approve":
        print("承認しました" if store.approve(args.id.upper(), args.by) else "承認できません（ID不正・期限切れ・承認者未登録）")
    elif args.cmd == "reject":
        print("却下しました" if store.reject(args.id.upper(), args.by) else "対象なし")
    elif args.cmd == "audit":
        for row in store.conn.execute("SELECT * FROM audit ORDER BY ts DESC LIMIT ?", (args.n,)):
            print(f"{row['ts']}  {row['result']:9}  {row['action']:24}  {row['detail']}")


if __name__ == "__main__":
    main()
