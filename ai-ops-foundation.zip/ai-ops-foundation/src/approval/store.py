"""承認待ちキュー＋監査ログ（SQLite）。外部依存なし。"""
from __future__ import annotations

import json
import os
import secrets
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

JST = timezone(timedelta(hours=9))


def now() -> datetime:
    return datetime.now(JST)


@dataclass
class ApprovalRecord:
    id: str
    action: str
    category: str
    payload_hash: str
    summary: str
    status: str  # pending / approved / rejected / consumed / expired
    requested_at: str
    expires_at: str
    approved_by: str | None = None
    approved_at: str | None = None
    payload_json: str | None = None


class ApprovalStore:
    def __init__(self, db_path: str):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init()

    def _init(self):
        c = self.conn
        c.execute("""CREATE TABLE IF NOT EXISTS approvals(
            id TEXT PRIMARY KEY, action TEXT, category TEXT, payload_hash TEXT, summary TEXT,
            status TEXT, requested_at TEXT, expires_at TEXT, approved_by TEXT, approved_at TEXT,
            payload_json TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS audit(
            ts TEXT, action TEXT, result TEXT, detail TEXT)""")
        c.commit()

    # ---- 依頼 ----
    def request(self, action, category, payload_hash, summary, ttl_minutes: int, payload: Any = None) -> ApprovalRecord:
        # 同一内容の pending があれば再利用（重複依頼を防ぐ）
        row = self.conn.execute(
            "SELECT * FROM approvals WHERE action=? AND payload_hash=? AND status='pending' AND expires_at>?",
            (action, payload_hash, now().isoformat()),
        ).fetchone()
        if row:
            return ApprovalRecord(**dict(row))
        rec = ApprovalRecord(
            id=secrets.token_hex(4).upper(),
            action=action, category=category, payload_hash=payload_hash, summary=summary,
            status="pending", requested_at=now().isoformat(),
            expires_at=(now() + timedelta(minutes=ttl_minutes)).isoformat(),
            payload_json=json.dumps(payload, ensure_ascii=False, default=str) if payload is not None else None,
        )
        self.conn.execute("INSERT INTO approvals VALUES (?,?,?,?,?,?,?,?,?,?,?)", (
            rec.id, rec.action, rec.category, rec.payload_hash, rec.summary, rec.status,
            rec.requested_at, rec.expires_at, rec.approved_by, rec.approved_at, rec.payload_json))
        self.conn.commit()
        return rec

    # ---- 人間の操作 ----
    def approve(self, rec_id: str, approver: str) -> bool:
        approvers = {a.strip() for a in os.getenv("APPROVERS", "").split(",") if a.strip()}
        if approver not in approvers:
            self.audit("approval.approve", "DENIED", f"unknown approver {approver} on {rec_id}")
            return False
        cur = self.conn.execute(
            "UPDATE approvals SET status='approved', approved_by=?, approved_at=? "
            "WHERE id=? AND status='pending' AND expires_at>?",
            (approver, now().isoformat(), rec_id, now().isoformat()))
        self.conn.commit()
        ok = cur.rowcount == 1
        self.audit("approval.approve", "OK" if ok else "NOOP", f"{rec_id} by {approver}")
        return ok

    def reject(self, rec_id: str, approver: str) -> bool:
        cur = self.conn.execute(
            "UPDATE approvals SET status='rejected', approved_by=?, approved_at=? WHERE id=? AND status='pending'",
            (approver, now().isoformat(), rec_id))
        self.conn.commit()
        self.audit("approval.reject", "OK" if cur.rowcount else "NOOP", f"{rec_id} by {approver}")
        return cur.rowcount == 1

    # ---- ゲート側 ----
    def find_approved(self, action: str, payload_hash: str) -> ApprovalRecord | None:
        row = self.conn.execute(
            "SELECT * FROM approvals WHERE action=? AND payload_hash=? AND status='approved' AND expires_at>?",
            (action, payload_hash, now().isoformat())).fetchone()
        return ApprovalRecord(**dict(row)) if row else None

    def consume(self, rec_id: str):
        self.conn.execute("UPDATE approvals SET status='consumed' WHERE id=?", (rec_id,))
        self.conn.commit()

    def pending(self) -> list[ApprovalRecord]:
        self.conn.execute("UPDATE approvals SET status='expired' WHERE status='pending' AND expires_at<=?",
                          (now().isoformat(),))
        self.conn.commit()
        rows = self.conn.execute("SELECT * FROM approvals WHERE status='pending' ORDER BY requested_at").fetchall()
        return [ApprovalRecord(**dict(r)) for r in rows]

    def audit(self, action: str, result: str, detail: str):
        self.conn.execute("INSERT INTO audit VALUES (?,?,?,?)", (now().isoformat(), action, result, detail))
        self.conn.commit()
