"""
モーニングブリーフィング バッチ（要件2・4）
  python -m src.brief.morning_brief            # 通常実行
  python -m src.brief.morning_brief --dry-run  # 配信せず標準出力のみ
  python -m src.brief.morning_brief --light    # 軽量巡回（未読件数＋承認待ちのみ、LLM不使用）

要件4（利用枠の枯渇防止）:
  - 1日の実行回数上限 (settings.schedule.max_runs_per_day) を data/runs.json で管理
  - LLM要約は settings.brief.use_llm_summary=true かつ 1日 token_budget.llm_calls_per_day 回まで
  - LLMに渡すのはメタ情報（件名・差出人・冒頭）だけ。本文は読まない
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")

from src.approval.store import ApprovalStore  # noqa: E402

JST = timezone(timedelta(hours=9))
SETTINGS = yaml.safe_load((ROOT / "config" / "settings.yaml").read_text(encoding="utf-8"))
RUNS_FILE = ROOT / "data" / "runs.json"


# ---------- 実行回数ガード ----------
def _runs_today() -> dict:
    today = datetime.now(JST).date().isoformat()
    data = json.loads(RUNS_FILE.read_text()) if RUNS_FILE.exists() else {}
    if data.get("date") != today:
        data = {"date": today, "runs": 0, "llm_calls": 0}
    return data


def _save_runs(d: dict):
    RUNS_FILE.parent.mkdir(parents=True, exist_ok=True)
    RUNS_FILE.write_text(json.dumps(d))


def guard_run() -> dict:
    d = _runs_today()
    if d["runs"] >= SETTINGS["schedule"]["max_runs_per_day"]:
        print(f"[guard] 本日の実行上限 {d['runs']} 回に達したため終了")
        sys.exit(0)
    d["runs"] += 1
    _save_runs(d)
    return d


# ---------- 収集 ----------
def collect(light: bool = False) -> dict:
    src = SETTINGS["sources"]
    out: dict = {"errors": []}
    try:
        if src["gmail"]["enabled"]:
            from src.connectors.gmail import list_unread
            out["mail"] = list_unread(src["gmail"]["query"], src["gmail"]["max_results"])
    except Exception as e:  # 片方が落ちてもブリーフは出す
        out["errors"].append(f"Gmail: {e}")
    if not light:
        try:
            if src["calendar"]["enabled"]:
                from src.connectors.calendar import today_events
                out["events"] = today_events(src["calendar"]["lookahead_hours"])
        except Exception as e:
            out["errors"].append(f"Calendar: {e}")
        try:
            if src["tasks"]["enabled"]:
                from src.connectors.tasks import due_tasks
                out["tasks"] = due_tasks()
        except Exception as e:
            out["errors"].append(f"Tasks: {e}")
    out["pending"] = ApprovalStore(os.getenv("APPROVAL_DB", str(ROOT / "data/approvals.sqlite3"))).pending()
    return out


# ---------- 整形（ルールベース：トークン消費ゼロ） ----------
def _fmt_when(w: str) -> str:
    if "T" in w:
        return datetime.fromisoformat(w).astimezone(JST).strftime("%H:%M")
    return "終日"


def render(data: dict, light: bool = False) -> str:
    now = datetime.now(JST)
    lines = [f"■ 今日のサマリー {now.strftime('%m/%d(%a) %H:%M')}"]
    mail = data.get("mail", [])
    lines.append(f"\n【未読メール】{len(mail)}件")
    for m in mail[: SETTINGS["brief"]["max_mail_lines"]]:
        sender = m["from"].split("<")[0].strip().strip('"') or m["from"]
        lines.append(f"・{sender}：{m['subject'][:40]}")
    if len(mail) > SETTINGS["brief"]["max_mail_lines"]:
        lines.append(f"　…他{len(mail) - SETTINGS['brief']['max_mail_lines']}件")
    if not light:
        ev = data.get("events", [])
        lines.append(f"\n【本日の予定】{len(ev)}件")
        for e in ev:
            loc = f"＠{e['location']}" if e["location"] else ""
            lines.append(f"・{_fmt_when(e['when'])} {e['title']}{loc}")
        t = data.get("tasks", {"overdue": [], "today": []})
        lines.append(f"\n【タスク】期限切れ{len(t['overdue'])}件／本日{len(t['today'])}件")
        for x in t["overdue"]:
            lines.append(f"・⚠️{x['due']} {x['title']}")
        for x in t["today"]:
            lines.append(f"・本日 {x['title']}")
    p = data.get("pending", [])
    lines.append(f"\n【承認待ち】{len(p)}件")
    for r in p:
        lines.append(f"・[{r.id}] {r.summary}")
    if data.get("errors"):
        lines.append("\n【取得エラー】" + " / ".join(data["errors"]))
    return "\n".join(lines)


# ---------- 任意：LLM要約（予算内のみ） ----------
def llm_summarize(text: str) -> str | None:
    if not SETTINGS["brief"]["use_llm_summary"] or not os.getenv("ANTHROPIC_API_KEY"):
        return None
    d = _runs_today()
    if d["llm_calls"] >= SETTINGS["token_budget"]["llm_calls_per_day"]:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic()
        cap = SETTINGS["token_budget"]["input_chars_cap"]
        msg = client.messages.create(
            model=os.getenv("BRIEF_MODEL", "claude-haiku-5-5"),
            max_tokens=int(os.getenv("BRIEF_MAX_OUTPUT_TOKENS", "800")),
            messages=[{"role": "user", "content":
                       "以下は経営者向けの朝のサマリーです。優先度順に3〜5行で要点のみ日本語で再整理してください。"
                       "推測や未記載の事実は加えないこと。\n\n" + text[:cap]}],
        )
        d["llm_calls"] += 1
        _save_runs(d)
        return "".join(b.text for b in msg.content if getattr(b, "type", "") == "text")
    except Exception as e:
        return f"(要約失敗: {e})"


# ---------- 配信 ----------
def deliver(text: str, pending: list, dry_run: bool):
    date = datetime.now(JST).strftime("%Y-%m-%d")
    if "file" in SETTINGS["brief"]["deliver_to"]:
        p = ROOT / "data" / "briefs" / f"{date}.md"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
    if dry_run:
        print(text)
        return
    if "chat" in SETTINGS["brief"]["deliver_to"]:
        from src.connectors.chat import post_brief
        post_brief(text, pending)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--light", action="store_true")
    args = ap.parse_args()
    guard_run()
    data = collect(light=args.light)
    text = render(data, light=args.light)
    if not args.light:
        s = llm_summarize(text)
        if s:
            text = "■ AI要約\n" + s.strip() + "\n\n" + text
    deliver(text, data.get("pending", []), args.dry_run)
    print(f"[ok] brief delivered ({'light' if args.light else 'full'})")


if __name__ == "__main__":
    main()
