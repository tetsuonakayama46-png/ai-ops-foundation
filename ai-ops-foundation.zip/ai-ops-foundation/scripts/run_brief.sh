#!/usr/bin/env bash
# cron から呼ぶラッパー。ログを日付ファイルへ。引数はそのまま morning_brief へ渡す（--light 等）
set -uo pipefail
cd "$(dirname "$0")/.."
. .venv/bin/activate
set -a; . ./.env; set +a
mkdir -p "${LOG_DIR:-data/logs}"
python -m src.brief.morning_brief "$@" >> "${LOG_DIR:-data/logs}/brief-$(date +%F).log" 2>&1
