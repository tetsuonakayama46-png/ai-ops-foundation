#!/usr/bin/env bash
# config/settings.yaml の schedule を crontab に登録（既存の ai-ops 行は置き換え）
set -euo pipefail
cd "$(dirname "$0")/.."
DIR="$(pwd)"
MORNING=$(python3 -c "import yaml;print(yaml.safe_load(open('config/settings.yaml'))['schedule']['morning_brief'])")
MIDDAY=$(python3 -c "import yaml;print(yaml.safe_load(open('config/settings.yaml'))['schedule']['midday_poll'])")
( crontab -l 2>/dev/null | grep -v '# ai-ops' || true
  echo "CRON_TZ=Asia/Tokyo"
  echo "$MORNING $DIR/scripts/run_brief.sh         # ai-ops morning"
  echo "$MIDDAY  $DIR/scripts/run_brief.sh --light # ai-ops light"
) | crontab -
echo "登録済み:"; crontab -l | grep 'ai-ops'
