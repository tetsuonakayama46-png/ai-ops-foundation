#!/usr/bin/env bash
# 環境構築（Ubuntu/Debian想定。VPS or 社内PC）
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip >/dev/null
pip install -r requirements.txt
mkdir -p data/logs data/briefs data/drafts
[ -f .env ] || cp .env.example .env
chmod 600 .env
echo "----------------------------------------------"
echo "1) .env を編集（LINEトークン・承認者ID 等）"
echo "2) Google Cloud で OAuthクライアント(デスクトップ) を作成し config/google_client_secret.json に保存"
echo "3) python scripts/oauth_init.py  で初回認可（ブラウザが開く）"
echo "4) python -m src.brief.morning_brief --dry-run  で動作確認"
echo "5) bash scripts/install_cron.sh  でスケジュール登録"
