"""初回のみ実行: Google OAuth 認可を行い data/google_token.json を作る。"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dotenv import load_dotenv
load_dotenv()
from src.connectors.google_auth import credentials
c = credentials()
print("OK: token saved. scopes =", c.scopes)
