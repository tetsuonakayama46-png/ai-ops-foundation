# MCP連携（対話側）と バッチ連携（cron側）の役割分担

本基盤は **2系統** で Gmail／カレンダー／社内チャットに接続します。

| 系統 | 用途 | 接続方法 | 送信・削除 |
|---|---|---|---|
| ① 対話（Claude.ai / Claude Code） | 人が指示して下書き・調査をさせる | MCPコネクター（Gmail・Google Calendar は Claude.ai 標準コネクター。Claude Code は下記 `mcp.json`） | Claude側の権限で人の承認プロンプトが出る |
| ② バッチ（cron） | 無人で収集→サマリー配信 | Python が Google API / LINE API を直接呼ぶ（`src/connectors/`） | コード内の承認ゲート（`src/approval/gate.py`）が止める |

会計ソフト（freee等）は ①のカスタムコネクターからの **手動実行のみ**。②からは呼ばない（`settings.yaml: sources.accounting.enabled=false`）。

## Claude Code 用 MCP 設定（`mcp/mcp.json`）
Claude Code のプロジェクト設定（`.mcp.json`）にコピーして使う。
`ai-ops-local` は本リポジトリの承認キューを Claude から読める自前MCPサーバー（`mcp/server.py`）。

```bash
cp mcp/mcp.json .mcp.json          # プロジェクト直下
claude                              # 起動後 /mcp で接続確認
```

- Gmail / Google Calendar は Claude.ai では標準コネクターを使う（設定 → コネクター）。
- Claude Code で使う場合は Google 公式/コミュニティの MCP サーバーを `mcp.json` に追加する。
  サーバー名・インストール方法は変わりやすいため、導入時点の公式ドキュメントで確認すること（本READMEでは特定パッケージ名を断定しない）。

## 自前MCPサーバー `ai-ops-local`
ツール:
- `list_pending_approvals` … 承認待ち一覧
- `list_today_brief` … 本日のブリーフィング本文
- `approve(id, by)` / `reject(id, by)` … 承認・却下（`APPROVERS` に登録済みIDのみ有効）

起動: `python mcp/server.py`（stdio）
