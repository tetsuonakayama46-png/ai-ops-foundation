"""最小MCPサーバー（stdio / JSON-RPC）。承認キューとブリーフィングをClaudeから参照・承認できるようにする。
外部ライブラリ不要。tools/list と tools/call のみ実装。"""
import json, os, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.approval.store import ApprovalStore  # noqa: E402

JST = timezone(timedelta(hours=9))
store = ApprovalStore(os.getenv("APPROVAL_DB", str(ROOT / "data/approvals.sqlite3")))

TOOLS = [
  {"name": "list_pending_approvals", "description": "承認待ち一覧", "inputSchema": {"type": "object", "properties": {}}},
  {"name": "list_today_brief", "description": "本日のブリーフィング本文", "inputSchema": {"type": "object", "properties": {}}},
  {"name": "approve", "description": "承認（承認者IDが必要）", "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}, "by": {"type": "string"}}, "required": ["id", "by"]}},
  {"name": "reject", "description": "却下", "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}, "by": {"type": "string"}}, "required": ["id", "by"]}},
]

def call(name, a):
    if name == "list_pending_approvals":
        return "\n".join(f"[{r.id}] {r.category} {r.action}: {r.summary} (期限 {r.expires_at})" for r in store.pending()) or "承認待ちなし"
    if name == "list_today_brief":
        p = ROOT / "data/briefs" / (datetime.now(JST).strftime("%Y-%m-%d") + ".md")
        return p.read_text(encoding="utf-8") if p.exists() else "本日分は未生成"
    if name == "approve":
        return "承認しました" if store.approve(a["id"].upper(), a["by"]) else "承認できません（権限/期限/ID）"
    if name == "reject":
        return "却下しました" if store.reject(a["id"].upper(), a["by"]) else "対象なし"
    return f"unknown tool {name}"

def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line); rid = req.get("id"); m = req.get("method")
        if m == "initialize":
            res = {"protocolVersion": "2024-11-05", "capabilities": {"tools": {}}, "serverInfo": {"name": "ai-ops-local", "version": "0.1"}}
        elif m == "tools/list":
            res = {"tools": TOOLS}
        elif m == "tools/call":
            res = {"content": [{"type": "text", "text": call(req["params"]["name"], req["params"].get("arguments", {}))}]}
        elif m and m.startswith("notifications/"):
            continue
        else:
            res = {}
        sys.stdout.write(json.dumps({"jsonrpc": "2.0", "id": rid, "result": res}, ensure_ascii=False) + "\n"); sys.stdout.flush()

if __name__ == "__main__":
    main()
