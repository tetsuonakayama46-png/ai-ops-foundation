"""承認ゲートの安全性テスト：承認なしでは副作用関数が絶対に実行されないこと。"""
import os, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pytest
from src.approval import gate as g
from src.approval.store import ApprovalStore


@pytest.fixture
def gate(tmp_path, monkeypatch):
    monkeypatch.setenv("APPROVERS", "U_CEO")
    gt = g.Gate(store=ApprovalStore(str(tmp_path / "a.sqlite3")))
    monkeypatch.setattr(g, "_default_gate", gt)
    return gt


def test_send_blocked_without_approval(gate):
    calls = []

    @g.requires_approval("gmail.send", summarize=lambda to, **_: f"to={to}")
    def send(to):
        calls.append(to)

    with pytest.raises(g.ApprovalRequired) as ei:
        send(to="customer@example.com")
    assert calls == []                      # 本体は実行されていない
    rec = ei.value.record
    assert rec.status == "pending" and rec.category == "A_send_message"

    # 承認者でない人の承認は無効
    assert gate.store.approve(rec.id, "SOMEONE") is False
    with pytest.raises(g.ApprovalRequired):
        send(to="customer@example.com")
    assert calls == []

    # 正規承認者が承認 → 実行される
    assert gate.store.approve(rec.id, "U_CEO") is True
    send(to="customer@example.com")
    assert calls == ["customer@example.com"]

    # 承認は使い切り：同じ内容でも再度は止まる
    with pytest.raises(g.ApprovalRequired):
        send(to="customer@example.com")
    assert calls == ["customer@example.com"]


def test_approval_bound_to_payload(gate):
    @g.requires_approval("file.delete", summarize=lambda path: f"rm {path}")
    def rm(path):
        return "deleted " + path

    with pytest.raises(g.ApprovalRequired) as ei:
        rm("/data/a.txt")
    gate.store.approve(ei.value.record.id, "U_CEO")
    with pytest.raises(g.ApprovalRequired):   # 別パスには流用できない
        rm("/data/b.txt")
    assert rm("/data/a.txt") == "deleted /data/a.txt"


def test_fail_closed_and_forbidden(gate):
    with pytest.raises(g.ForbiddenAction):
        gate.check("unknown.action", {}, "x")          # ポリシー未定義 → 拒否
    with pytest.raises(g.ForbiddenAction):
        gate.check("bank.credentials_input", {}, "x")  # 明示禁止
    gate.check("gmail.create_draft", {"to": "a"}, "draft")  # 下書きは通る


def test_all_four_categories_require_approval(gate):
    for action in ["gmail.send", "payment.execute", "doc.sign", "file.delete"]:
        assert gate.policy.classify(action) == "approval"
