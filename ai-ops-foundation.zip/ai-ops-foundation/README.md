# ai-ops-foundation — 自律型AI社員 業務フロー基盤 v1.0

「自律的な情報収集」＋「人間への承認依頼」を基本とする、秀和建工向けの業務自動化基盤。

| 要件 | 実装 |
|---|---|
| 1 ツール連携 | `src/connectors/`（Gmail / Calendar / Tasks / LINE・Slack）、`mcp/`（Claude Code連携） |
| 2 モーニングブリーフィング | `src/brief/morning_brief.py` + `cron/` |
| 3 承認フロー（A送信/B支払/C署名/D削除） | `src/approval/`（fail-closed、1回使い切り、監査ログ、テスト付） |
| 4 利用枠最適化 | 指定時刻のみ起動・1日4回上限・本文非読込・LLM要約は既定OFF |

- 構築手順: `docs/SETUP.md`
- 運用ルール: `docs/OPERATING_RULES.md`
- 構成: `docs/ARCHITECTURE.md`

```bash
bash scripts/setup.sh && python scripts/oauth_init.py
python -m src.brief.morning_brief --dry-run
python -m pytest -q tests
bash scripts/install_cron.sh
```
