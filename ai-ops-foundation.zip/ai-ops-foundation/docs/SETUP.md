# 環境構築手順（要件1・2）

対象: Ubuntu 22.04 以降のVPS、または社内PC（常時起動）。所要 約60分。

## STEP 0　前提
- Python 3.11 以上
- 社用 Google アカウント（Gmail・カレンダー・Google Tasks）
- LINE公式アカウント（Messaging API 有効化済み）※Slackの場合は `CHAT_PROVIDER=slack`

## STEP 1　配置とライブラリ
```bash
sudo mkdir -p /opt && cd /opt
unzip ai-ops-foundation.zip && cd ai-ops-foundation
bash scripts/setup.sh
```

## STEP 2　Google OAuth（Gmail / Calendar / Tasks）
1. Google Cloud Console → 新規プロジェクト（例: `shuwa-ai-ops`）
2. 「APIとサービス」→ 以下を **有効化**: Gmail API / Google Calendar API / Tasks API
3. 「OAuth同意画面」→ 内部（Workspace）または外部（テストユーザーに自分を追加）
4. 「認証情報」→「OAuthクライアントID」→ 種類 **デスクトップアプリ** → JSONをダウンロード
5. `config/google_client_secret.json` として保存
6. 初回認可（ブラウザが開く。VPSなら手元PCで実行して `data/google_token.json` をコピー）
   ```bash
   python scripts/oauth_init.py
   ```
   要求スコープは **gmail.modify / calendar.readonly / tasks.readonly** のみ（最小権限）。

## STEP 3　LINE（承認ボタン＋配信先）
1. LINE Developers → Messaging API チャネル → **チャネルアクセストークン（長期）** と **チャネルシークレット** を `.env` へ
2. 自分のユーザーID（`U...`）を `LINE_TARGET_ID` と `APPROVERS` に設定
   - 取得方法: Webhook を一度有効にし、公式アカウントへメッセージを送るとイベントの `source.userId` に出る
3. 承認ボタンを使う場合（任意）: Webhook を常駐
   ```bash
   sudo cp cron/ai-ops-webhook.service /etc/systemd/system/
   sudo systemctl enable --now ai-ops-webhook
   ```
   公開URLは nginx + Let's Encrypt、または Cloudflare Tunnel で `https://<host>/line/webhook` を LINE Developers に登録。
   ボタンを使わない場合は CLI 承認（`python -m src.approval.cli approve <ID> --by <自分のID>`）で足りる。

## STEP 4　動作確認
```bash
. .venv/bin/activate
python -m src.brief.morning_brief --dry-run     # 標準出力にサマリー
python -m pytest -q tests                       # 承認ゲートのテスト 4件が通ること
```

## STEP 5　スケジュール登録（要件4）
```bash
bash scripts/install_cron.sh
```
登録内容（`config/settings.yaml` から生成）
- 07:00 月〜土 … フル（未読・予定・タスク・承認待ち）
- 12:00 / 16:00 … 軽量（未読件数・承認待ちのみ。LLMは使わない）
- 1日 **最大4回**。超過起動は `data/runs.json` で自動拒否。

## STEP 6　Claude側（対話）からの参照
- Claude.ai: Gmail / Google Calendar コネクターをそのまま使用（標準）。
- Claude Code: `cp mcp/mcp.json .mcp.json` → `/mcp` で `ai-ops-local` が見えれば、
  `list_pending_approvals` / `approve` がチャットから使える。

## トラブル時
| 症状 | 確認 |
|---|---|
| `invalid_grant` | token が失効。`data/google_token.json` を削除して STEP 2-6 を再実行 |
| LINE 401 | `.env` のトークン／シークレット。Webhook署名検証はシークレット必須 |
| サマリーが来ない | `data/logs/brief-YYYY-MM-DD.log` と `data/runs.json`（上限到達なら `runs` が4） |
