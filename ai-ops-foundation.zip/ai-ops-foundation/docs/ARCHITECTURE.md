# アーキテクチャ

```
          ┌──────────── 指定時刻のみ起動（cron, 1日≤4回）────────────┐
          │  scripts/run_brief.sh → src/brief/morning_brief.py        │
          │     ├ guard_run()      実行回数ガード (data/runs.json)     │
          │     ├ collect()        Gmail / Calendar / Tasks（読み取り）│
          │     ├ render()         ルールベース整形（トークン0）        │
          │     ├ llm_summarize()  任意・予算内のみ（Claude API）       │
          │     └ deliver()        LINE/Slack 配信 + data/briefs/*.md  │
          └───────────────────────────────────────────────────────────┘
                              │ 承認待ち一覧 + [承認][却下]ボタン
                              ▼
  ┌──────────────── 承認ゲート src/approval ────────────────┐
  │ gate.py    @requires_approval → Policy.classify()       │
  │            auto / approval(A-D) / forbidden(fail-closed) │
  │ store.py   SQLite: approvals(pending→approved→consumed) │
  │            audit（全判断の記録）                          │
  │ webhook.py LINE postback（署名検証）→ approve/reject     │
  │ cli.py     人手承認（ボタン無し環境）                      │
  └──────────────────────────────────────────────────────────┘
                              ▲
  Claude.ai / Claude Code ───┘ mcp/server.py (ai-ops-local)
  （対話側: 標準Gmail/Calendarコネクター。会計は手動のみ）
```

## ディレクトリ
- `config/` 設定・承認ポリシー（唯一の権限定義）
- `src/connectors/` 外部API（副作用関数は必ず `@requires_approval`）
- `src/approval/` ゲート・キュー・承認UI
- `src/brief/` ブリーフィングバッチ
- `mcp/` Claude Code 連携
- `cron/` crontab / systemd 雛形
- `tests/` 承認ゲートの安全性テスト
- `data/` 実行時生成（token, DB, ログ, ブリーフ）— Git管理外
